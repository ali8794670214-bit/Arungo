import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import MerchantDashboard from '../app/(merchant)/dashboard/page';

describe('Merchant Dashboard', () => {
  it('renders title', () => {
    render(<MerchantDashboard />);
    expect(screen.getByText(/Merchant Dashboard/i)).toBeInTheDocument();
  });
});
