'use client';

import React, { useState, useEffect } from 'react';
import { 
  LineChart, Line, XAxis, YAxis, CartesianGrid, 
  Tooltip, ResponsiveContainer 
} from 'recharts';
import { db } from '@/lib/firebase';
import { 
  collection, getDocs, query, orderBy, 
  updateDoc, doc, Timestamp, limit 
} from 'firebase/firestore';

interface Shop {
  id: string;
  name: string;
  category: string;
  status: string;
}

interface Order {
  id: string;
  customerId: string;
  total: number;
  status: string;
}

interface DeliveryPartner {
  id: string;
  name: string;
  phone: string;
  vehicleType: string;
  status: string;
}

const revenueData = [
  { month: 'Jan', revenue: 124000 },
  { month: 'Feb', revenue: 145000 },
  { month: 'Mar', revenue: 167000 },
  { month: 'Apr', revenue: 189000 },
  { month: 'May', revenue: 210000 },
  { month: 'Jun', revenue: 234500 },
];

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState<'overview' | 'shops' | 'delivery' | 'orders' | 'revenue' | 'settings'>('overview');
  const [shops, setShops] = useState<Shop[]>([]);
  const [partners, setPartners] = useState<DeliveryPartner[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);

  const fetchData = async () => {
    try {
      const shopsSnap = await getDocs(query(collection(db, 'shops'), orderBy('createdAt', 'desc')));
      setShops(shopsSnap.docs.map(d => ({ id: d.id, ...d.data() } as Shop)));

      setPartners([
        { id: 'd1', name: 'Amit Singh', phone: '+919876543210', vehicleType: 'bike', status: 'pending' },
        { id: 'd2', name: 'Ravi Kumar', phone: '+919812345678', vehicleType: 'scooter', status: 'approved' },
      ]);

      const ordersSnap = await getDocs(query(collection(db, 'orders'), orderBy('createdAt', 'desc'), limit(20)));
      setOrders(ordersSnap.docs.map(d => ({ id: d.id, ...d.data() } as Order)));
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const approveShop = async (shopId: string) => {
    await updateDoc(doc(db, 'shops', shopId), { status: 'approved', approvedAt: Timestamp.now() });
    fetchData();
  };

  const rejectShop = async (shopId: string) => {
    await updateDoc(doc(db, 'shops', shopId), { status: 'rejected' });
    fetchData();
  };

  const approvePartner = (id: string) => {
    setPartners(prev => prev.map(p => p.id === id ? { ...p, status: 'approved' } : p));
  };

  const totalRevenue = orders.reduce((sum, o) => sum + (o.total || 0), 0);

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-6 py-6">
          <h1 className="text-3xl font-semibold text-gray-900">Admin Dashboard</h1>
          <p className="text-gray-600 mt-1">ArunGo Platform Management</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="flex flex-wrap gap-1 mb-8 border-b">
          {[
            { key: 'overview', label: 'Overview' },
            { key: 'shops', label: 'Shops' },
            { key: 'delivery', label: 'Delivery Partners' },
            { key: 'orders', label: 'Orders' },
            { key: 'revenue', label: 'Revenue' },
            { key: 'settings', label: 'Settings' },
          ].map(({ key, label }) => (
            <button
              key={key}
              onClick={() => setActiveTab(key as any)}
              className={`px-6 py-3 text-sm font-medium border-b-2 transition-all ${
                activeTab === key ? 'border-emerald-600 text-emerald-700' : 'border-transparent text-gray-600'
              }`}
            >
              {label}
            </button>
          ))}
        </div>

        {activeTab === 'overview' && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="bg-white rounded-3xl p-8 border"><p className="text-sm text-gray-600">Total Shops</p><p className="text-4xl font-semibold mt-2">{shops.length}</p></div>
            <div className="bg-white rounded-3xl p-8 border"><p className="text-sm text-gray-600">Total Orders</p><p className="text-4xl font-semibold mt-2">{orders.length}</p></div>
            <div className="bg-white rounded-3xl p-8 border"><p className="text-sm text-gray-600">Total Revenue</p><p className="text-4xl font-semibold mt-2">₹{totalRevenue}</p></div>
            <div className="bg-white rounded-3xl p-8 border"><p className="text-sm text-gray-600">Delivery Partners</p><p className="text-4xl font-semibold mt-2">{partners.length}</p></div>
          </div>
        )}

        {activeTab === 'shops' && (
          <div className="bg-white rounded-3xl border p-8">
            <h2 className="text-2xl font-semibold mb-6">Shop Management</h2>
            <table className="w-full text-sm">
              <thead><tr className="border-b"><th className="text-left py-4">Shop</th><th className="text-left py-4">Category</th><th className="text-left py-4">Status</th><th className="text-right py-4">Actions</th></tr></thead>
              <tbody>
                {shops.map(shop => (
                  <tr key={shop.id} className="border-b">
                    <td className="py-4 font-medium">{shop.name}</td>
                    <td className="py-4 capitalize">{shop.category}</td>
                    <td className="py-4"><span className={`px-3 py-1 rounded-full text-xs font-medium ${shop.status === 'approved' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'}`}>{shop.status}</span></td>
                    <td className="py-4 text-right space-x-2">
                      {shop.status === 'pending' && (
                        <>
                          <button onClick={() => approveShop(shop.id)} className="px-4 py-2 bg-emerald-600 text-white rounded-2xl text-sm">Approve</button>
                          <button onClick={() => rejectShop(shop.id)} className="px-4 py-2 border border-gray-300 rounded-2xl text-sm">Reject</button>
                        </>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {activeTab === 'delivery' && (
          <div className="bg-white rounded-3xl border p-8">
            <h2 className="text-2xl font-semibold mb-6">Delivery Partner Approvals</h2>
            <table className="w-full text-sm">
              <thead><tr className="border-b"><th className="text-left py-4">Name</th><th className="text-left py-4">Phone</th><th className="text-left py-4">Vehicle</th><th className="text-left py-4">Status</th><th className="text-right py-4">Action</th></tr></thead>
              <tbody>
                {partners.map(p => (
                  <tr key={p.id} className="border-b">
                    <td className="py-4 font-medium">{p.name}</td>
                    <td className="py-4">{p.phone}</td>
                    <td className="py-4 capitalize">{p.vehicleType}</td>
                    <td className="py-4"><span className="px-3 py-1 rounded-full text-xs bg-amber-100 text-amber-700">{p.status}</span></td>
                    <td className="py-4 text-right">{p.status === 'pending' && <button onClick={() => approvePartner(p.id)} className="px-5 py-2 bg-emerald-600 text-white rounded-2xl text-sm">Approve</button>}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {activeTab === 'orders' && (
          <div className="bg-white rounded-3xl border p-8">
            <h2 className="text-2xl font-semibold mb-6">All Orders</h2>
            <table className="w-full text-sm">
              <thead><tr className="border-b"><th className="text-left py-4">Order ID</th><th className="text-left py-4">Customer</th><th className="text-left py-4">Total</th><th className="text-left py-4">Status</th></tr></thead>
              <tbody>
                {orders.map(o => (
                  <tr key={o.id} className="border-b">
                    <td className="py-4 font-mono text-sm">{o.id}</td>
                    <td className="py-4">{o.customerId}</td>
                    <td className="py-4 font-semibold">₹{o.total}</td>
                    <td className="py-4 capitalize">{o.status}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {activeTab === 'revenue' && (
          <div className="bg-white rounded-3xl p-8 border">
            <h3 className="font-semibold mb-6">Revenue Trend</h3>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={revenueData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="revenue" stroke="#10b981" strokeWidth={3} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        )}

        {activeTab === 'settings' && (
          <div className="bg-white rounded-3xl border p-8 max-w-md">
            <h2 className="text-2xl font-semibold mb-6">Commission Settings</h2>
            <div className="space-y-4">
              <input type="number" defaultValue="10" className="w-full border rounded-2xl px-4 py-3" placeholder="Platform Commission %" />
              <input type="number" defaultValue="15" className="w-full border rounded-2xl px-4 py-3" placeholder="Delivery Commission %" />
              <button className="w-full py-3 bg-emerald-600 text-white rounded-2xl font-medium">Save Settings</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
