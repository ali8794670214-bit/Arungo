import { test, expect } from '@playwright/test';

test.describe('Admin Dashboard', () => {
  test('should load admin dashboard', async ({ page }) => {
    await page.goto('/(admin)/dashboard');
    await expect(page.getByText('Admin Dashboard')).toBeVisible();
  });

  test('should show shop approval section', async ({ page }) => {
    await page.goto('/(admin)/dashboard');
    await expect(page.getByText('Shop Approval Queue')).toBeVisible();
  });

  test('should allow approving a shop', async ({ page }) => {
    await page.goto('/(admin)/dashboard');
    const approveButton = page.getByRole('button', { name: 'Approve' }).first();
    if (await approveButton.isVisible()) {
      await approveButton.click();
    }
  });
});