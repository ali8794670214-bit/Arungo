import { test, expect } from '@playwright/test';

test.describe('Delivery Partner Dashboard', () => {
  test('should load delivery dashboard', async ({ page }) => {
    await page.goto('/(delivery)/dashboard');
    await expect(page.getByText('Delivery Partner Dashboard')).toBeVisible();
  });

  test('should show available jobs', async ({ page }) => {
    await page.goto('/(delivery)/dashboard');
    await expect(page.getByText(/Available Orders/i)).toBeVisible();
  });

  test('should switch to wallet tab', async ({ page }) => {
    await page.goto('/(delivery)/dashboard');
    await page.getByText('Wallet').click();
    await expect(page.getByText(/Current Balance/i)).toBeVisible();
  });
});