import { test, expect } from '@playwright/test';

test.describe('Merchant Dashboard', () => {
  test('should load merchant dashboard', async ({ page }) => {
    await page.goto('/(merchant)/dashboard');
    await expect(page.getByText('Merchant Dashboard')).toBeVisible();
  });

  test('should allow adding a product', async ({ page }) => {
    await page.goto('/(merchant)/dashboard');
    
    await page.getByPlaceholder('Product name').fill('Test Basmati Rice');
    await page.getByPlaceholder('Price (₹)').fill('299');
    await page.getByPlaceholder('Stock').fill('50');
    
    await page.getByRole('button', { name: 'Add Product' }).click();
    
    await expect(page.getByText('Test Basmati Rice')).toBeVisible();
  });

  test('should switch to earnings tab', async ({ page }) => {
    await page.goto('/(merchant)/dashboard');
    await page.getByText('Earnings').click();
    await expect(page.getByText(/Total Earnings/i)).toBeVisible();
  });
});