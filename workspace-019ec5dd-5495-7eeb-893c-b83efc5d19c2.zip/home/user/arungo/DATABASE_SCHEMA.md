# ArunGo Database Schema (Firestore)

## Collections

### users
- uid (string, doc ID)
- role: "customer" | "merchant" | "delivery" | "admin"
- name, email, phone, address, createdAt
- membership: { plan: "basic"|"premium", expiresAt }

### shops
- id (doc ID)
- ownerId, name, category: "food"|"grocery"|"medicine", address, location (GeoPoint)
- status: "pending"|"approved"|"rejected"
- membership: "basic"|"premium"
- rating, createdAt

### products
- id, shopId, name, price, category, stock, imageUrl, createdAt

### orders
- id, customerId, shopId, items[], total, status, deliveryPartnerId, createdAt, deliveryAddress

### deliveries
- id, orderId, partnerId, status, earnings, timestamp

### parcels
- id, customerId, pickupAddress, dropAddress, weight, status, price

### earnings
- partnerId (doc), totalEarnings, transactions[] 

### memberships
- userId, plan, amount, paymentId, startDate, endDate

## Indexes Recommended
- shops: status + category
- orders: customerId + status
- deliveries: partnerId + status