# Firebase Integration Guide for ArunGo

## 1. Firebase Project Setup

1. Go to [Firebase Console](https://console.firebase.google.com)
2. Create a new project (or use existing)
3. Enable the following services:
   - **Authentication** → Email/Password + Google (recommended)
   - **Firestore Database** → Create database (start in test mode)
   - **Storage** → Enable Cloud Storage

## 2. Get Firebase Config

1. Go to **Project Settings** (gear icon)
2. Scroll to "Your apps" → Click Web (`</>`)
3. Copy the `firebaseConfig` object

## 3. Environment Variables

Create `.env.local` in the root of the project:

```env
NEXT_PUBLIC_FIREBASE_API_KEY=AIzaSy...
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=arungo-xxx.firebaseapp.com
NEXT_PUBLIC_FIREBASE_PROJECT_ID=arungo-xxx
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=arungo-xxx.appspot.com
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=123456789
NEXT_PUBLIC_FIREBASE_APP_ID=1:123456789:web:abc123
```

Copy from `.env.example` and fill in real values.

## 4. Files Created

| File                        | Purpose                              |
|----------------------------|--------------------------------------|
| `lib/firebase.ts`          | Firebase initialization              |
| `lib/auth.ts`              | Authentication (register, login, logout) |
| `lib/firestore.ts`         | Firestore CRUD operations            |
| `lib/storage.ts`           | File uploads (products, shops, profile) |
| `.env.example`             | Environment variable template        |

## 5. Usage Examples

### Authentication
```tsx
import { registerUser, loginUser, logoutUser } from '@/lib/auth';

// Register
const user = await registerUser('email@test.com', 'password123', {
  name: 'John Doe',
  phone: '+919876543210',
  role: 'customer'
});

// Login
const user = await loginUser('email@test.com', 'password123');

// Logout
await logoutUser();
```

### Firestore Operations
```tsx
import { createShop, addProduct, createOrder } from '@/lib/firestore';

// Create shop
const shopId = await createShop({
  ownerId: user.uid,
  name: 'My Store',
  category: 'grocery',
  ...
});

// Add product
await addProduct({
  shopId,
  name: 'Rice 5kg',
  price: 320,
  stock: 50,
  ...
});
```

### Storage
```tsx
import { uploadProductImage } from '@/lib/storage';

const imageUrl = await uploadProductImage(file, productId);
```

## 6. Security Rules

Copy the rules from `FIRESTORE_SCHEMA.md` into:
**Firebase Console → Firestore → Rules**

## 7. Next Steps

- Replace mock data in dashboards with real Firestore calls
- Add `onAuthStateChange` listener in layout
- Implement role-based redirects after login

Firebase connection is now ready for ArunGo!