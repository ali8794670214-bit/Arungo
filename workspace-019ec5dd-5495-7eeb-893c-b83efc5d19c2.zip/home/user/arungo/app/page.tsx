import Link from 'next/link';

export default function Home() {
  return (
    <div className="min-h-screen bg-white">
      <nav className="border-b">
        <div className="max-w-7xl mx-auto px-6 py-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 bg-emerald-600 rounded-2xl flex items-center justify-center">
              <span className="text-white font-bold text-2xl">A</span>
            </div>
            <span className="font-semibold text-3xl tracking-tight">ArunGo</span>
          </div>
          <div className="flex gap-4">
            <Link href="/(admin)/dashboard" className="px-6 py-2.5 rounded-3xl border text-sm font-medium hover:bg-gray-50">
              Admin Dashboard
            </Link>
            <Link href="/login" className="px-6 py-2.5 bg-emerald-600 text-white rounded-3xl text-sm font-medium">
              Login
            </Link>
          </div>
        </div>
      </nav>

      <div className="max-w-4xl mx-auto px-6 pt-24 pb-20 text-center">
        <div className="inline-block px-4 py-1 rounded-full bg-emerald-100 text-emerald-700 text-sm font-medium mb-6">
          Local Commerce Platform
        </div>
        <h1 className="text-7xl font-semibold tracking-tighter text-gray-900 mb-6">
          ArunGo
        </h1>
        <p className="text-2xl text-gray-600 max-w-2xl mx-auto mb-10">
          The complete local commerce platform for customers, merchants, and delivery partners.
        </p>
          <div className="flex gap-4 justify-center">
          <Link href="/(admin)/dashboard" className="px-8 py-4 rounded-3xl bg-emerald-600 text-white font-medium text-lg hover:bg-emerald-700">
            Admin Dashboard
          </Link>
          <Link href="/(merchant)/dashboard" className="px-8 py-4 rounded-3xl border border-emerald-600 text-emerald-700 font-medium text-lg hover:bg-emerald-50">
            Merchant Dashboard
          </Link>
          <Link href="/(delivery)/dashboard" className="px-8 py-4 rounded-3xl border border-emerald-600 text-emerald-700 font-medium text-lg hover:bg-emerald-50">
            Delivery Partner
          </Link>
        </div>
      </div>
    </div>
  );
}
