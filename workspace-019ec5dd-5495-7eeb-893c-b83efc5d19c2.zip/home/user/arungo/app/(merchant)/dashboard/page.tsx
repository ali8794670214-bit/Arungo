'use client';

import React, { useState } from 'react';

interface Product {
  id: string;
  name: string;
  price: number;
  stock: number;
  category: string;
}

interface Order {
  id: string;
  customer: string;
  items: number;
  total: number;
  status: string;
  time: string;
}

interface AdPlan {
  id: string;
  name: string;
  price: number;
  duration: string;
  impressions: string;
}

const initialProducts: Product[] = [
  { id: 'p1', name: 'Basmati Rice 5kg', price: 320, stock: 45, category: 'grocery' },
  { id: 'p2', name: 'Fresh Tomatoes 1kg', price: 45, stock: 120, category: 'grocery' },
  { id: 'p3', name: 'Paneer 200g', price: 85, stock: 30, category: 'grocery' },
];

const initialOrders: Order[] = [
  { id: 'o101', customer: 'Anita Sharma', items: 4, total: 560, status: 'pending', time: '10 min ago' },
  { id: 'o102', customer: 'Rohan Patel', items: 2, total: 180, status: 'preparing', time: '25 min ago' },
];

const adPlans: AdPlan[] = [
  { id: 'ad1', name: 'Featured Shop', price: 1500, duration: '7 days', impressions: '25K' },
  { id: 'ad2', name: 'Homepage Banner', price: 3500, duration: '14 days', impressions: '80K' },
];

export default function MerchantDashboard() {
  const [activeTab, setActiveTab] = useState<'products' | 'orders' | 'earnings' | 'subscription' | 'ads'>('products');
  const [products, setProducts] = useState<Product[]>(initialProducts);
  const [orders, setOrders] = useState<Order[]>(initialOrders);
  const [newProduct, setNewProduct] = useState({ name: '', price: 0, stock: 0, category: 'grocery' });

  // Product Management
  const addProduct = () => {
    if (!newProduct.name) return;
    const product: Product = {
      id: 'p' + Date.now(),
      ...newProduct,
    };
    setProducts([...products, product]);
    setNewProduct({ name: '', price: 0, stock: 0, category: 'grocery' });
  };

  const updateStock = (id: string, newStock: number) => {
    setProducts(prev => prev.map(p => p.id === id ? { ...p, stock: newStock } : p));
  };

  const deleteProduct = (id: string) => {
    setProducts(prev => prev.filter(p => p.id !== id));
  };

  // Order Management
  const updateOrderStatus = (id: string, status: string) => {
    setOrders(prev => prev.map(o => o.id === id ? { ...o, status } : o));
  };

  // Earnings
  const totalEarnings = orders.reduce((sum, o) => sum + o.total, 0);

  return (
    <div>
      <div className="mb-8 flex items-end justify-between">
        <div>
          <h1 className="text-4xl font-semibold text-gray-900">Merchant Dashboard</h1>
          <p className="text-gray-600 mt-1">Fresh Mart • Grocery Store</p>
        </div>
        <div className="text-right">
          <div className="text-sm text-gray-500">Current Plan</div>
          <div className="font-semibold text-emerald-600">Premium (Expires: 12 Mar 2026)</div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 mb-8 border-b overflow-x-auto">
        {[
          { key: 'products', label: 'Products & Inventory' },
          { key: 'orders', label: 'Orders' },
          { key: 'earnings', label: 'Earnings' },
          { key: 'subscription', label: 'Subscription' },
          { key: 'ads', label: 'Advertisements' },
        ].map(tab => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key as any)}
            className={`px-6 py-3 text-sm font-medium border-b-2 whitespace-nowrap transition-all ${
              activeTab === tab.key
                ? 'border-emerald-600 text-emerald-700'
                : 'border-transparent text-gray-600 hover:text-gray-900'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* PRODUCTS & INVENTORY */}
      {activeTab === 'products' && (
        <div className="space-y-8">
          {/* Add Product */}
          <div className="bg-white rounded-3xl border border-gray-200 p-8">
            <h2 className="text-2xl font-semibold mb-6">Add New Product</h2>
            <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
              <input
                type="text"
                placeholder="Product name"
                className="border border-gray-300 rounded-2xl px-4 py-3"
                value={newProduct.name}
                onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })}
              />
              <input
                type="number"
                placeholder="Price (₹)"
                className="border border-gray-300 rounded-2xl px-4 py-3"
                value={newProduct.price || ''}
                onChange={(e) => setNewProduct({ ...newProduct, price: Number(e.target.value) })}
              />
              <input
                type="number"
                placeholder="Stock"
                className="border border-gray-300 rounded-2xl px-4 py-3"
                value={newProduct.stock || ''}
                onChange={(e) => setNewProduct({ ...newProduct, stock: Number(e.target.value) })}
              />
              <select
                className="border border-gray-300 rounded-2xl px-4 py-3"
                value={newProduct.category}
                onChange={(e) => setNewProduct({ ...newProduct, category: e.target.value })}
              >
                <option value="grocery">Grocery</option>
                <option value="food">Food</option>
                <option value="medicine">Medicine</option>
              </select>
              <button
                onClick={addProduct}
                className="bg-emerald-600 text-white rounded-2xl font-medium hover:bg-emerald-700"
              >
                Add Product
              </button>
            </div>
          </div>

          {/* Product List */}
          <div className="bg-white rounded-3xl border border-gray-200 p-8">
            <h2 className="text-2xl font-semibold mb-6">Product Catalog ({products.length})</h2>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-3">Product</th>
                    <th className="text-left py-3">Price</th>
                    <th className="text-left py-3">Stock</th>
                    <th className="text-left py-3">Category</th>
                    <th className="text-right py-3">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {products.map(product => (
                    <tr key={product.id} className="border-b last:border-0">
                      <td className="py-4 font-medium">{product.name}</td>
                      <td className="py-4">₹{product.price}</td>
                      <td className="py-4">
                        <input
                          type="number"
                          value={product.stock}
                          onChange={(e) => updateStock(product.id, parseInt(e.target.value))}
                          className="w-20 border border-gray-300 rounded-xl px-3 py-1 text-center"
                        />
                      </td>
                      <td className="py-4 capitalize">{product.category}</td>
                      <td className="py-4 text-right">
                        <button
                          onClick={() => deleteProduct(product.id)}
                          className="text-red-600 hover:text-red-700 text-sm"
                        >
                          Delete
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ORDERS */}
      {activeTab === 'orders' && (
        <div className="bg-white rounded-3xl border border-gray-200 p-8">
          <h2 className="text-2xl font-semibold mb-6">Incoming Orders</h2>
          <div className="space-y-4">
            {orders.map(order => (
              <div key={order.id} className="flex items-center justify-between border border-gray-200 rounded-2xl p-6">
                <div>
                  <div className="font-semibold">{order.customer}</div>
                  <div className="text-sm text-gray-500">{order.items} items • {order.time}</div>
                </div>
                <div className="text-right">
                  <div className="font-semibold text-xl">₹{order.total}</div>
                  <select
                    value={order.status}
                    onChange={(e) => updateOrderStatus(order.id, e.target.value)}
                    className="mt-1 border border-gray-300 rounded-2xl px-4 py-1 text-sm"
                  >
                    <option value="pending">Pending</option>
                    <option value="preparing">Preparing</option>
                    <option value="ready">Ready for Pickup</option>
                    <option value="completed">Completed</option>
                  </select>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* EARNINGS */}
      {activeTab === 'earnings' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white rounded-3xl border border-gray-200 p-8">
            <div className="text-sm text-gray-600">Total Earnings (This Month)</div>
            <div className="text-5xl font-semibold text-emerald-600 mt-2">₹{totalEarnings}</div>
          </div>
          <div className="bg-white rounded-3xl border border-gray-200 p-8">
            <div className="text-sm text-gray-600">Orders Completed</div>
            <div className="text-5xl font-semibold mt-2">{orders.length}</div>
          </div>
          <div className="bg-white rounded-3xl border border-gray-200 p-8">
            <div className="text-sm text-gray-600">Average Order Value</div>
            <div className="text-5xl font-semibold mt-2">₹{Math.round(totalEarnings / orders.length) || 0}</div>
          </div>
        </div>
      )}

      {/* SUBSCRIPTION */}
      {activeTab === 'subscription' && (
        <div className="bg-white rounded-3xl border border-gray-200 p-8">
          <h2 className="text-2xl font-semibold mb-6">Membership Plans</h2>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="border border-emerald-200 rounded-3xl p-8">
              <div className="text-emerald-600 font-semibold">CURRENT PLAN</div>
              <div className="text-3xl font-semibold mt-2">Premium</div>
              <div className="text-4xl font-semibold mt-4">₹1,200<span className="text-lg text-gray-500">/year</span></div>
              <ul className="mt-6 space-y-2 text-sm">
                <li>✓ Featured shop placement</li>
                <li>✓ Lower commission rate (8%)</li>
                <li>✓ Priority support</li>
              </ul>
              <button className="mt-8 w-full py-3 border border-emerald-600 text-emerald-700 rounded-2xl font-medium">Renew Plan</button>
            </div>
            <div className="border border-gray-200 rounded-3xl p-8">
              <div className="text-3xl font-semibold mt-2">Basic</div>
              <div className="text-4xl font-semibold mt-4">₹500<span className="text-lg text-gray-500">/year</span></div>
              <ul className="mt-6 space-y-2 text-sm">
                <li>✓ Standard listing</li>
                <li>✓ Standard commission (12%)</li>
              </ul>
              <button className="mt-8 w-full py-3 bg-emerald-600 text-white rounded-2xl font-medium">Upgrade to Premium</button>
            </div>
          </div>
        </div>
      )}

      {/* ADVERTISEMENTS */}
      {activeTab === 'ads' && (
        <div className="bg-white rounded-3xl border border-gray-200 p-8">
          <h2 className="text-2xl font-semibold mb-6">Purchase Advertisements</h2>
          <div className="grid md:grid-cols-2 gap-6">
            {adPlans.map(plan => (
              <div key={plan.id} className="border border-gray-200 rounded-3xl p-8">
                <div className="font-semibold text-xl">{plan.name}</div>
                <div className="text-4xl font-semibold mt-4">₹{plan.price}</div>
                <div className="text-sm text-gray-600 mt-1">{plan.duration} • {plan.impressions} impressions</div>
                <button className="mt-8 w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-2xl font-medium">
                  Purchase Ad
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
