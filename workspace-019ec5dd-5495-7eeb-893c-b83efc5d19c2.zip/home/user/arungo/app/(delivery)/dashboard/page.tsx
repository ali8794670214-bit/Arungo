'use client';

import React, { useState } from 'react';

interface AvailableOrder {
  id: string;
  shop: string;
  customer: string;
  address: string;
  distance: string;
  earnings: number;
  type: 'order' | 'parcel';
}

interface ActiveDelivery {
  id: string;
  shop: string;
  customer: string;
  status: string;
  earnings: number;
  eta: string;
}

interface Transaction {
  id: string;
  type: string;
  amount: number;
  date: string;
}

const availableOrders: AvailableOrder[] = [
  { id: 'o201', shop: 'Fresh Mart', customer: 'Priya Gupta', address: 'Sector 15, Noida', distance: '2.3 km', earnings: 45, type: 'order' },
  { id: 'p301', shop: 'Parcel Pickup', customer: 'Rahul Verma', address: 'Sector 62, Noida', distance: '4.1 km', earnings: 65, type: 'parcel' },
];

const initialActiveDeliveries: ActiveDelivery[] = [
  { id: 'o198', shop: 'Spice Kitchen', customer: 'Meera Kapoor', status: 'Picked Up', earnings: 55, eta: '12 min' },
];

const initialWallet = 2450;
const initialTransactions: Transaction[] = [
  { id: 't1', type: 'Delivery #o195', amount: 55, date: 'Today' },
  { id: 't2', type: 'Parcel #p289', amount: 70, date: 'Yesterday' },
];

export default function DeliveryPartnerDashboard() {
  const [activeTab, setActiveTab] = useState<'available' | 'active' | 'earnings' | 'wallet' | 'parcels'>('available');
  const [available, setAvailable] = useState(availableOrders);
  const [activeDeliveries, setActiveDeliveries] = useState(initialActiveDeliveries);
  const [wallet, setWallet] = useState(initialWallet);
  const [transactions, setTransactions] = useState(initialTransactions);

  // Accept order/parcel
  const acceptDelivery = (order: AvailableOrder) => {
    const newDelivery: ActiveDelivery = {
      id: order.id,
      shop: order.shop,
      customer: order.customer,
      status: 'Accepted',
      earnings: order.earnings,
      eta: '25 min',
    };
    setActiveDeliveries([...activeDeliveries, newDelivery]);
    setAvailable(prev => prev.filter(o => o.id !== order.id));
  };

  // Update status
  const updateStatus = (id: string, newStatus: string) => {
    setActiveDeliveries(prev =>
      prev.map(d => {
        if (d.id === id) {
          const updated = { ...d, status: newStatus };
          if (newStatus === 'Delivered') {
            // Move earnings to wallet
            setWallet(w => w + d.earnings);
            setTransactions(t => [{ id: 't' + Date.now(), type: `Delivery #${id}`, amount: d.earnings, date: 'Just now' }, ...t]);
          }
          return updated;
        }
        return d;
      })
    );
  };

  // Complete and remove from active
  const completeDelivery = (id: string) => {
    setActiveDeliveries(prev => prev.filter(d => d.id !== id));
  };

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-4xl font-semibold text-gray-900">Delivery Partner Dashboard</h1>
        <p className="text-gray-600 mt-1">Amit Singh • Online • 34 deliveries this week</p>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 mb-8 border-b overflow-x-auto">
        {[
          { key: 'available', label: 'Available Jobs' },
          { key: 'active', label: 'Active Deliveries' },
          { key: 'earnings', label: 'Earnings' },
          { key: 'wallet', label: 'Wallet' },
          { key: 'parcels', label: 'Parcels' },
        ].map(tab => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key as any)}
            className={`px-6 py-3 text-sm font-medium border-b-2 whitespace-nowrap transition-all ${
              activeTab === tab.key
                ? 'border-emerald-600 text-emerald-700'
                : 'border-transparent text-gray-600 hover:text-gray-900'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* AVAILABLE JOBS */}
      {activeTab === 'available' && (
        <div className="bg-white rounded-3xl border border-gray-200 p-8">
          <h2 className="text-2xl font-semibold mb-6">Available Orders &amp; Parcels</h2>
          <div className="space-y-4">
            {available.length === 0 && <p className="text-gray-500">No jobs available right now.</p>}
            {available.map(order => (
              <div key={order.id} className="flex items-center justify-between border border-gray-200 rounded-2xl p-6">
                <div>
                  <div className="font-semibold">{order.shop}</div>
                  <div className="text-sm text-gray-600">{order.customer} • {order.address}</div>
                  <div className="text-xs text-emerald-600 mt-1">{order.distance} away</div>
                </div>
                <div className="text-right">
                  <div className="font-semibold text-xl">₹{order.earnings}</div>
                  <button
                    onClick={() => acceptDelivery(order)}
                    className="mt-2 px-6 py-2 bg-emerald-600 text-white rounded-2xl text-sm font-medium hover:bg-emerald-700"
                  >
                    Accept {order.type === 'parcel' ? 'Parcel' : 'Order'}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ACTIVE DELIVERIES */}
      {activeTab === 'active' && (
        <div className="bg-white rounded-3xl border border-gray-200 p-8">
          <h2 className="text-2xl font-semibold mb-6">My Active Deliveries</h2>
          {activeDeliveries.length === 0 && <p className="text-gray-500">No active deliveries.</p>}
          <div className="space-y-4">
            {activeDeliveries.map(delivery => (
              <div key={delivery.id} className="border border-gray-200 rounded-2xl p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <div className="font-semibold">{delivery.shop} → {delivery.customer}</div>
                    <div className="text-sm text-gray-600 mt-1">ETA: {delivery.eta}</div>
                  </div>
                  <div className="text-right">
                    <div className="font-semibold text-xl">₹{delivery.earnings}</div>
                    <div className="text-xs text-emerald-600">{delivery.status}</div>
                  </div>
                </div>

                <div className="mt-4 flex gap-3 flex-wrap">
                  {delivery.status === 'Accepted' && (
                    <button onClick={() => updateStatus(delivery.id, 'Picked Up')} className="px-5 py-2 bg-emerald-600 text-white rounded-2xl text-sm">Mark Picked Up</button>
                  )}
                  {delivery.status === 'Picked Up' && (
                    <button onClick={() => updateStatus(delivery.id, 'Delivered')} className="px-5 py-2 bg-emerald-600 text-white rounded-2xl text-sm">Mark Delivered</button>
                  )}
                  {delivery.status === 'Delivered' && (
                    <button onClick={() => completeDelivery(delivery.id)} className="px-5 py-2 border border-gray-300 rounded-2xl text-sm">Complete &amp; Remove</button>
                  )}
                  <button className="px-5 py-2 border border-gray-300 rounded-2xl text-sm">Open Navigation</button>
                  <button className="px-5 py-2 border border-gray-300 rounded-2xl text-sm">Live Track</button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* EARNINGS */}
      {activeTab === 'earnings' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white rounded-3xl border border-gray-200 p-8">
            <div className="text-sm text-gray-600">Total Earnings (This Month)</div>
            <div className="text-5xl font-semibold text-emerald-600 mt-2">₹{wallet}</div>
          </div>
          <div className="bg-white rounded-3xl border border-gray-200 p-8">
            <div className="text-sm text-gray-600">Deliveries Completed</div>
            <div className="text-5xl font-semibold mt-2">{transactions.length}</div>
          </div>
          <div className="bg-white rounded-3xl border border-gray-200 p-8">
            <div className="text-sm text-gray-600">Average Per Delivery</div>
            <div className="text-5xl font-semibold mt-2">₹{Math.round(wallet / transactions.length) || 0}</div>
          </div>
        </div>
      )}

      {/* WALLET */}
      {activeTab === 'wallet' && (
        <div className="bg-white rounded-3xl border border-gray-200 p-8">
          <div className="flex justify-between items-center mb-8">
            <div>
              <div className="text-sm text-gray-600">Current Balance</div>
              <div className="text-6xl font-semibold text-emerald-600">₹{wallet}</div>
            </div>
            <button className="px-8 py-3 bg-emerald-600 text-white rounded-2xl font-medium">Withdraw to Bank</button>
          </div>

          <h3 className="font-semibold mb-4">Recent Transactions</h3>
          <div className="space-y-3">
            {transactions.map(tx => (
              <div key={tx.id} className="flex justify-between border-b pb-3 last:border-0">
                <div>{tx.type}</div>
                <div className="font-medium text-emerald-600">+₹{tx.amount}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* PARCELS */}
      {activeTab === 'parcels' && (
        <div className="bg-white rounded-3xl border border-gray-200 p-8">
          <h2 className="text-2xl font-semibold mb-6">Parcel Deliveries</h2>
          <p className="text-gray-600">Parcel jobs are shown in the Available Jobs tab. You can accept parcel pickups and deliveries the same way as regular orders.</p>
          <div className="mt-6 text-sm text-gray-500">Live tracking and navigation will be available once a parcel is accepted.</div>
        </div>
      )}
    </div>
  );
}
