import React from 'react';

export default function DeliveryLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="min-h-screen bg-gray-50">
      <nav className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between max-w-7xl mx-auto">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 bg-emerald-600 rounded-xl flex items-center justify-center">
              <span className="text-white font-bold text-xl">A</span>
            </div>
            <div>
              <span className="font-semibold text-2xl text-gray-900">ArunGo</span>
              <span className="ml-2 text-sm px-3 py-0.5 bg-emerald-100 text-emerald-700 rounded-full font-medium">Delivery</span>
            </div>
          </div>
          <div className="flex items-center gap-4 text-sm">
            <div className="text-gray-600">Amit Singh • Bike • DL-7S-4821</div>
            <div className="w-9 h-9 bg-emerald-200 rounded-full flex items-center justify-center text-emerald-700 font-medium">AS</div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {children}
      </div>
    </div>
  );
}
