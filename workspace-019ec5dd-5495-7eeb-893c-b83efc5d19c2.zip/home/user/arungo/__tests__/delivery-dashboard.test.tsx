import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import DeliveryDashboard from '../app/(delivery)/dashboard/page';

describe('Delivery Partner Dashboard', () => {
  test('renders delivery dashboard', () => {
    render(<DeliveryDashboard />);
    expect(screen.getByText(/Delivery Partner Dashboard/i)).toBeInTheDocument();
  });

  test('shows available jobs', () => {
    render(<DeliveryDashboard />);
    expect(screen.getByText(/Available Orders/i)).toBeInTheDocument();
  });

  test('can switch to wallet tab', () => {
    render(<DeliveryDashboard />);
    fireEvent.click(screen.getByText('Wallet'));
    expect(screen.getByText(/Current Balance/i)).toBeInTheDocument();
  });
});
