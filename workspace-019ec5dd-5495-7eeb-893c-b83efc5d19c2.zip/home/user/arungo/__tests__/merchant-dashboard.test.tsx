import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import MerchantDashboard from '../app/(merchant)/dashboard/page';

describe('Merchant Dashboard', () => {
  test('renders merchant dashboard title', () => {
    render(<MerchantDashboard />);
    expect(screen.getByText(/Merchant Dashboard/i)).toBeInTheDocument();
  });

  test('can add a new product', () => {
    render(<MerchantDashboard />);

    fireEvent.change(screen.getByPlaceholderText('Product name'), {
      target: { value: 'Test Product' },
    });
    fireEvent.change(screen.getByPlaceholderText('Price (₹)'), {
      target: { value: '100' },
    });
    fireEvent.change(screen.getByPlaceholderText('Stock'), {
      target: { value: '50' },
    });

    fireEvent.click(screen.getByText('Add Product'));

    expect(screen.getByText('Test Product')).toBeInTheDocument();
  });

  test('shows earnings correctly', () => {
    render(<MerchantDashboard />);
    fireEvent.click(screen.getByText('Earnings'));
    expect(screen.getByText(/Total Earnings/i)).toBeInTheDocument();
  });
});
