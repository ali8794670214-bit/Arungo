# ArunGo - Complete Firestore Database Schema (Production Ready)

## Collections Overview

| Collection          | Purpose                              | Key Fields                          |
|---------------------|--------------------------------------|-------------------------------------|
| `users`             | All platform users                   | uid, role, email, phone             |
| `shops`             | Merchant stores                      | ownerId, status, category, membership |
| `products`          | Shop inventory                       | shopId, name, price, stock          |
| `orders`            | Customer orders                      | customerId, shopId, status, total   |
| `delivery_partners` | Delivery personnel                   | uid, vehicle, earnings, location    |
| `memberships`       | Subscription plans                   | userId, plan, amount, endDate       |
| `advertisements`    | Paid promotions                      | shopId, type, budget, status        |
| `parcels`           | Parcel delivery requests             | customerId, pickup, drop, status    |
| `transactions`      | All financial records                | userId, type, amount, status        |

---

## 1. Collection Structures & Document Examples

### users
**Document ID**: Firebase Auth UID

```json
{
  "uid": "uid_customer_001",
  "email": "customer@example.com",
  "phone": "+919876543210",
  "name": "Rahul Sharma",
  "role": "customer",
  "address": {
    "line1": "B-42, Sector 15",
    "city": "Noida",
    "state": "Uttar Pradesh",
    "pincode": "201301",
    "latitude": 28.5706,
    "longitude": 77.3272
  },
  "profileImage": "https://...",
  "createdAt": "2025-01-10T08:30:00Z",
  "updatedAt": "2025-06-14T10:15:00Z",
  "isActive": true
}
```

### shops
**Document ID**: Auto-generated

```json
{
  "id": "shop_freshmart_001",
  "ownerId": "uid_merchant_042",
  "name": "Fresh Mart Grocery",
  "category": "grocery",
  "description": "Fresh vegetables, fruits & daily groceries",
  "address": {
    "line1": "Shop 12, Main Market",
    "city": "Noida",
    "pincode": "201301",
    "latitude": 28.5721,
    "longitude": 77.3265
  },
  "phone": "+919812345678",
  "status": "approved",
  "approvedBy": "uid_admin_001",
  "approvedAt": "2025-01-12T11:00:00Z",
  "membership": "premium",
  "membershipExpiresAt": "2026-01-12T00:00:00Z",
  "rating": 4.6,
  "totalOrders": 1247,
  "createdAt": "2025-01-10T09:45:00Z",
  "updatedAt": "2025-06-14T09:20:00Z",
  "isActive": true
}
```

### products
**Document ID**: Auto-generated

```json
{
  "id": "prod_rice_5kg",
  "shopId": "shop_freshmart_001",
  "name": "Basmati Rice 5kg",
  "description": "Premium aged basmati rice",
  "price": 320,
  "discountPrice": 299,
  "category": "grocery",
  "stock": 87,
  "unit": "pack",
  "imageUrl": "https://...",
  "isAvailable": true,
  "createdAt": "2025-02-01T10:00:00Z",
  "updatedAt": "2025-06-10T14:30:00Z"
}
```

### orders
**Document ID**: Auto-generated

```json
{
  "id": "order_98765",
  "customerId": "uid_customer_001",
  "shopId": "shop_freshmart_001",
  "items": [
    {
      "productId": "prod_rice_5kg",
      "name": "Basmati Rice 5kg",
      "price": 299,
      "quantity": 2,
      "total": 598
    }
  ],
  "subtotal": 598,
  "deliveryFee": 35,
  "total": 633,
  "status": "assigned",
  "paymentStatus": "paid",
  "paymentMethod": "upi",
  "deliveryAddress": {
    "line1": "B-42, Sector 15",
    "city": "Noida",
    "pincode": "201301",
    "latitude": 28.5706,
    "longitude": 77.3272
  },
  "deliveryPartnerId": "uid_delivery_007",
  "estimatedDeliveryTime": "2025-06-14T15:45:00Z",
  "createdAt": "2025-06-14T14:20:00Z",
  "updatedAt": "2025-06-14T14:35:00Z"
}
```

### delivery_partners
**Document ID**: Firebase Auth UID

```json
{
  "uid": "uid_delivery_007",
  "name": "Amit Singh",
  "phone": "+919876543210",
  "email": "amit.delivery@gmail.com",
  "vehicleType": "bike",
  "vehicleNumber": "DL-7S-4821",
  "currentLocation": {
    "latitude": 28.5715,
    "longitude": 77.3258
  },
  "isAvailable": true,
  "rating": 4.8,
  "totalDeliveries": 312,
  "earnings": 45600,
  "createdAt": "2025-01-20T11:00:00Z",
  "updatedAt": "2025-06-14T10:45:00Z"
}
```

### memberships
**Document ID**: Auto-generated

```json
{
  "id": "mem_premium_042",
  "userId": "uid_merchant_042",
  "plan": "premium",
  "amount": 1200,
  "currency": "INR",
  "startDate": "2025-01-12T00:00:00Z",
  "endDate": "2026-01-12T00:00:00Z",
  "paymentId": "pay_razorpay_123456",
  "status": "active",
  "createdAt": "2025-01-12T10:15:00Z"
}
```

### advertisements
**Document ID**: Auto-generated

```json
{
  "id": "ad_featured_001",
  "shopId": "shop_freshmart_001",
  "title": "Fresh Mart - Premium Grocery",
  "description": "Get fresh vegetables & groceries at best prices",
  "imageUrl": "https://...",
  "type": "featured",
  "startDate": "2025-06-01T00:00:00Z",
  "endDate": "2025-06-30T23:59:59Z",
  "budget": 1500,
  "status": "active",
  "clicks": 1240,
  "impressions": 48500,
  "createdAt": "2025-05-28T16:00:00Z"
}
```

### parcels
**Document ID**: Auto-generated

```json
{
  "id": "parcel_5566",
  "customerId": "uid_customer_001",
  "pickupAddress": {
    "line1": "Shop 12, Main Market",
    "city": "Noida",
    "pincode": "201301",
    "latitude": 28.5721,
    "longitude": 77.3265
  },
  "dropAddress": {
    "line1": "B-42, Sector 15",
    "city": "Noida",
    "pincode": "201301",
    "latitude": 28.5706,
    "longitude": 77.3272
  },
  "weight": 2.5,
  "dimensions": "30x20x15 cm",
  "description": "Documents and clothes",
  "price": 65,
  "status": "picked_up",
  "deliveryPartnerId": "uid_delivery_007",
  "createdAt": "2025-06-14T11:30:00Z",
  "updatedAt": "2025-06-14T12:15:00Z"
}
```

### transactions
**Document ID**: Auto-generated

```json
{
  "id": "txn_778899",
  "userId": "uid_customer_001",
  "orderId": "order_98765",
  "parcelId": null,
  "type": "order_payment",
  "amount": 633,
  "currency": "INR",
  "status": "success",
  "paymentMethod": "upi",
  "razorpayPaymentId": "pay_razorpay_987654",
  "createdAt": "2025-06-14T14:22:00Z"
}
```

---

## 2. Relationships

| From Collection     | Relationship     | To Collection          | Field                  |
|---------------------|------------------|------------------------|------------------------|
| `users`             | 1 → many         | `shops`                | `shops.ownerId`        |
| `shops`             | 1 → many         | `products`             | `products.shopId`      |
| `shops`             | 1 → many         | `orders`               | `orders.shopId`        |
| `users`             | 1 → many         | `orders` (customer)    | `orders.customerId`    |
| `delivery_partners` | 1 → many         | `orders`               | `orders.deliveryPartnerId` |
| `users`             | 1 → many         | `memberships`          | `memberships.userId`   |
| `shops`             | 1 → many         | `advertisements`       | `advertisements.shopId`|
| `users`             | 1 → many         | `parcels`              | `parcels.customerId`   |
| `users`             | 1 → many         | `transactions`         | `transactions.userId`  |
| `orders`            | 1 → many         | `transactions`         | `transactions.orderId` |

---

## 3. Recommended Firestore Indexes

Create these indexes in Firebase Console → Firestore → Indexes:

### Composite Indexes

| Collection     | Fields                                      | Query Type     | Purpose                          |
|----------------|---------------------------------------------|----------------|----------------------------------|
| `shops`        | `status` + `category` + `createdAt`         | Composite      | Admin approval + category filter |
| `orders`       | `customerId` + `status` + `createdAt`       | Composite      | Customer order history           |
| `orders`       | `shopId` + `status` + `createdAt`           | Composite      | Merchant order management        |
| `orders`       | `deliveryPartnerId` + `status`              | Composite      | Delivery partner active orders   |
| `products`     | `shopId` + `isAvailable` + `createdAt`      | Composite      | Shop product listing             |
| `advertisements` | `shopId` + `status` + `startDate`         | Composite      | Active ads per shop              |
| `transactions` | `userId` + `type` + `createdAt`             | Composite      | User transaction history         |
| `parcels`      | `customerId` + `status` + `createdAt`       | Composite      | Customer parcel tracking         |

### Single Field Indexes (Auto-created by Firestore)
- All `createdAt`, `updatedAt`, `status`, `role` fields

---

## 4. Firestore Security Rules

Create file: `firebase/firestore.rules`

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {

    // ==================== HELPER FUNCTIONS ====================
    function isAuthenticated() {
      return request.auth != null;
    }
    
    function getUserRole() {
      return get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role;
    }
    
    function isAdmin() {
      return isAuthenticated() && getUserRole() == 'admin';
    }
    
    function isMerchant() {
      return isAuthenticated() && getUserRole() == 'merchant';
    }
    
    function isDeliveryPartner() {
      return isAuthenticated() && getUserRole() == 'delivery';
    }
    
    function isCustomer() {
      return isAuthenticated() && getUserRole() == 'customer';
    }

    // ==================== USERS ====================
    match /users/{userId} {
      allow read: if isAuthenticated() && (request.auth.uid == userId || isAdmin());
      allow create: if isAuthenticated() && request.auth.uid == userId;
      allow update: if isAuthenticated() && (request.auth.uid == userId || isAdmin());
    }

    // ==================== SHOPS ====================
    match /shops/{shopId} {
      allow read: if true;
      allow create: if isMerchant();
      allow update: if isMerchant() && resource.data.ownerId == request.auth.uid || isAdmin();
      allow delete: if isAdmin();
    }

    // ==================== PRODUCTS ====================
    match /products/{productId} {
      allow read: if true;
      allow create, update, delete: if isMerchant() && 
        get(/databases/$(database)/documents/shops/$(resource.data.shopId)).data.ownerId == request.auth.uid;
    }

    // ==================== ORDERS ====================
    match /orders/{orderId} {
      allow read: if isAuthenticated() && (
        resource.data.customerId == request.auth.uid ||
        resource.data.shopId in getShopIdsForMerchant() ||
        resource.data.deliveryPartnerId == request.auth.uid ||
        isAdmin()
      );
      
      allow create: if isCustomer();
      allow update: if isAuthenticated() && (
        resource.data.customerId == request.auth.uid ||
        isMerchantForShop(resource.data.shopId) ||
        resource.data.deliveryPartnerId == request.auth.uid ||
        isAdmin()
      );
    }

    // ==================== DELIVERY_PARTNERS ====================
    match /delivery_partners/{partnerId} {
      allow read: if isAuthenticated();
      allow create, update: if request.auth.uid == partnerId || isAdmin();
    }

    // ==================== MEMBERSHIPS ====================
    match /memberships/{membershipId} {
      allow read, create: if isAuthenticated() && resource.data.userId == request.auth.uid;
      allow update: if isAdmin();
    }

    // ==================== ADVERTISEMENTS ====================
    match /advertisements/{adId} {
      allow read: if true;
      allow create, update: if isMerchant() && 
        get(/databases/$(database)/documents/shops/$(resource.data.shopId)).data.ownerId == request.auth.uid || isAdmin();
    }

    // ==================== PARCELS ====================
    match /parcels/{parcelId} {
      allow read: if isAuthenticated() && (
        resource.data.customerId == request.auth.uid ||
        resource.data.deliveryPartnerId == request.auth.uid ||
        isAdmin()
      );
      allow create: if isCustomer();
      allow update: if isAuthenticated();
    }

    // ==================== TRANSACTIONS ====================
    match /transactions/{transactionId} {
      allow read: if isAuthenticated() && (
        resource.data.userId == request.auth.uid || isAdmin()
      );
      allow create: if isAuthenticated();
    }
  }
}
```

---

## Summary

This schema is **production-ready** and covers:
- All 9 required collections
- Realistic document examples
- Clear relationships
- Recommended composite indexes
- Complete role-based security rules

You can directly use this schema when connecting your Next.js app to Firebase.