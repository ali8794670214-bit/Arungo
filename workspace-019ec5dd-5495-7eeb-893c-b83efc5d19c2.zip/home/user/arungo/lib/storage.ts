import { ref, uploadBytes, getDownloadURL, deleteObject } from 'firebase/storage';
import { storage } from './firebase';

// Upload file to Firebase Storage
export const uploadFile = async (file: File, path: string): Promise<string> => {
  const storageRef = ref(storage, path);
  await uploadBytes(storageRef, file);
  const downloadURL = await getDownloadURL(storageRef);
  return downloadURL;
};

// Upload product image
export const uploadProductImage = async (file: File, productId: string) => {
  const path = `products/${productId}/${file.name}`;
  return uploadFile(file, path);
};

// Upload shop image / banner
export const uploadShopImage = async (file: File, shopId: string) => {
  const path = `shops/${shopId}/${file.name}`;
  return uploadFile(file, path);
};

// Upload user profile picture
export const uploadProfileImage = async (file: File, userId: string) => {
  const path = `users/${userId}/profile.${file.name.split('.').pop()}`;
  return uploadFile(file, path);
};

// Delete file from storage
export const deleteFile = async (path: string) => {
  const storageRef = ref(storage, path);
  await deleteObject(storageRef);
};