import {
  collection,
  doc,
  addDoc,
  getDoc,
  getDocs,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  Timestamp,
} from 'firebase/firestore';
import { db } from './firebase';

// ==================== USERS ====================
export const getUser = async (uid: string) => {
  const docRef = doc(db, 'users', uid);
  const docSnap = await getDoc(docRef);
  return docSnap.exists() ? docSnap.data() : null;
};

// ==================== SHOPS ====================
export const createShop = async (shopData: any) => {
  const docRef = await addDoc(collection(db, 'shops'), {
    ...shopData,
    createdAt: Timestamp.now(),
    status: 'pending',
  });
  return docRef.id;
};

export const getShopsByStatus = async (status: string) => {
  const q = query(
    collection(db, 'shops'),
    where('status', '==', status),
    orderBy('createdAt', 'desc')
  );
  const snapshot = await getDocs(q);
  return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
};

export const approveShop = async (shopId: string, adminId: string) => {
  await updateDoc(doc(db, 'shops', shopId), {
    status: 'approved',
    approvedBy: adminId,
    approvedAt: Timestamp.now(),
  });
};

// ==================== PRODUCTS ====================
export const addProduct = async (productData: any) => {
  const docRef = await addDoc(collection(db, 'products'), {
    ...productData,
    createdAt: Timestamp.now(),
    updatedAt: Timestamp.now(),
  });
  return docRef.id;
};

export const getProductsByShop = async (shopId: string) => {
  const q = query(collection(db, 'products'), where('shopId', '==', shopId));
  const snapshot = await getDocs(q);
  return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
};

export const updateProductStock = async (productId: string, newStock: number) => {
  await updateDoc(doc(db, 'products', productId), {
    stock: newStock,
    updatedAt: Timestamp.now(),
  });
};

// ==================== ORDERS ====================
export const createOrder = async (orderData: any) => {
  const docRef = await addDoc(collection(db, 'orders'), {
    ...orderData,
    createdAt: Timestamp.now(),
    updatedAt: Timestamp.now(),
    status: 'pending',
  });
  return docRef.id;
};

export const getOrdersByCustomer = async (customerId: string) => {
  const q = query(
    collection(db, 'orders'),
    where('customerId', '==', customerId),
    orderBy('createdAt', 'desc')
  );
  const snapshot = await getDocs(q);
  return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
};

export const updateOrderStatus = async (orderId: string, status: string) => {
  await updateDoc(doc(db, 'orders', orderId), {
    status,
    updatedAt: Timestamp.now(),
  });
};

// ==================== DELIVERY PARTNERS ====================
export const updateDeliveryLocation = async (uid: string, location: any) => {
  await updateDoc(doc(db, 'delivery_partners', uid), {
    currentLocation: location,
    updatedAt: Timestamp.now(),
  });
};

// ==================== PARCELS ====================
export const createParcel = async (parcelData: any) => {
  const docRef = await addDoc(collection(db, 'parcels'), {
    ...parcelData,
    createdAt: Timestamp.now(),
    status: 'requested',
  });
  return docRef.id;
};